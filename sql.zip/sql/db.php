<?php
$dbServername="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="dbscm";
$db=mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName) or die("unable to connect");
echo"great work";
?> 