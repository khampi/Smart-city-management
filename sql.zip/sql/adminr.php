<?php

$first=$_post['First name'];
$last=$_post['Last name'];
$userid=$_post['UserID'];
$pwd=$_post['Password'];


$conn = new mysqli('localhost','root','','dbscm');
if($conn->connect_error){
	die('connection Failed  :  '.Sconn->Connect_error);
}else{
	$stmt = $conn->prepare("insert into adminregistration(First name, Last name, UserID, Password )
	      values(?, ?, ?, ?)");
	$stmt->bind_param("sssi",$first, $last,	$userid, $pwd );
	$stmt->execute();
	$stmt->close();
	$stmt->close();
?>

